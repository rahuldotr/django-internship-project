from  django.urls import path
from . import views
from django.contrib.auth import views as auth_views
from django.conf.urls import include, url

urlpatterns = [

#REDIRECT PATHS
path('', views.index, name='index'),
path('about/', views.about, name='index'),
path('portfolio/', views.portfolio, name='index'),
path('portfolio/', views.portfolio, name='index'),
path('Contact-Us/', views.contact, name='index'),

#ACTION PATHS
path('register/', views.signup, name='blog'),
path('Login_user/', views.login_123, name='blog'),
path('logout/', views.logout_view, name='blog'),









]