from django.shortcuts import render
from django.http import HttpResponse
from django.core.paginator import Paginator
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login
from django.contrib.auth import logout
from django.http import  HttpResponseRedirect     
from django.shortcuts import redirect
from django.contrib import messages
from django.shortcuts import get_object_or_404, render
from django.core.mail import EmailMessage
from django.http import JsonResponse
from django.contrib.auth import authenticate
from django.views.decorators.csrf import csrf_exempt
from rest_framework.authtoken.models import Token
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.status import (
    HTTP_400_BAD_REQUEST,
    HTTP_404_NOT_FOUND,
    HTTP_200_OK
)
from rest_framework.response import Response
from rest_framework.authtoken.views import obtain_auth_token




from .forms import SignupForm
from .forms import LoginForm





# Create your views here.


def index(request):
	return render(request,"whitebricks/index.html")

def about(request):
	return render(request,"whitebricks/about.html")	

def portfolio(request):
	return render(request,"whitebricks/portfolio.html")	

def contact(request):
	return render(request,"whitebricks/contact.html")	


def signup(request):
	if request.method == 'POST':
			signup_form = SignupForm(request.POST)
			if signup_form.is_valid():
				username = signup_form.cleaned_data['username']	
				email = signup_form.cleaned_data['email']	
				password = signup_form.cleaned_data['password']	
				password = signup_form.cleaned_data['password']	

				if  User.objects.filter(username=username).exists():
					messages.warning(request, 'Account already exists/Invalid data')
				else:	
				
					user = User.objects.create_user(username, email, password)
					user.save()
					return render(request, "whitebricks/signupsuccess.html")
                       
 
	else:
		signup_form = SignupForm(request.POST)
	return render(request, 'whitebricks/register.html',{"form":signup_form})


def login_123(request):
        if request.user.is_authenticated:
                return render(request,"blog/dashboard.html")
        else:	
                if request.method == 'POST':
                        login_form = LoginForm(request.POST)
                        if login_form.is_valid():

                                username = login_form.cleaned_data['username']
                                password = login_form.cleaned_data['password']

                                user = authenticate(username=username, password=password)
                                                                
                                if user is not None:
                                        if user.is_active:
                                                login(request, user)	
                                                return render(request,"whitebricks/index.html")
                                        else:
                                                messages.success(request, 'The Account not active..!!')  # <-
                                else:
                                        # return HttpResponse('The Account does not exists')
                                        messages.success(request, 'The Account does not exists')  # <-

                        else:
                                login_form = LoginForm()
                                return render(request, "whitebricks/login.html",{"form":login_form})
                else:
                        login_form = LoginForm()
                return render(request, "whitebricks/login.html",{"form":login_form})

def logout_view(request):
    logout(request)
    return render(request,"whitebricks/index.html")





