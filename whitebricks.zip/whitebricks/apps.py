from django.apps import AppConfig


class WhitebricksConfig(AppConfig):
    name = 'whitebricks'
